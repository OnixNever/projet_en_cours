# Gestionnaire de Profils — v0.3

Application Android : plusieurs profils de navigation isolés (cookies, connexions, stockage),
avec micro et caméra autorisés ou non profil par profil. Interface sombre.

## Fonctions
- Créer, renommer, recolorer, supprimer un profil (appui long ou ⋮ sur la liste, ⚙ dans le navigateur)
- Liste des profils sauvegardée (SharedPreferences), dernière page rétablie à la réouverture
- Changement rapide de profil : toucher la pastille colorée en haut
- Permissions micro / caméra réglées par profil ; tout le reste est refusé
- Barre d'adresse (URL ou recherche Google), barre de progression, bouton retour
- Suppression : efface cookies et données du profil puis supprime le profil WebView

## Compiler (sans Android Studio)
1. Poussez ce dossier dans un dépôt GitHub privé
2. Onglet Actions → « Build APK » → Run workflow
3. Téléchargez l'artefact `gestionnaire-profils-apk`, installez l'APK

## À vérifier sur le téléphone
- Un bandeau orange sur l'écran des profils signale que l'isolation n'est pas supportée
- Cookie posé dans un profil (ex. connexion) absent des autres
- Deux comptes Google / Claude différents dans deux profils
- Micro : accordé dans un profil avec l'option, refusé dans les autres
- Supprimer un profil puis en recréer un : aucune session restante

## Limites connues
- Pas d'onglets multiples, pas d'envoi/téléchargement de fichiers
- La connexion Google dépend du masquage de la WebView (User-Agent) : peut casser si Google durcit ses règles

## Nouveautés v0.3
- Palette de couleurs libre (carré saturation/luminosité + teinte) avec quelques couleurs rapides
- Pop-ups gérées dans le même profil (connexion Google « Se connecter avec Google » sur Claude) ; bouton retour pour fermer la pop-up
