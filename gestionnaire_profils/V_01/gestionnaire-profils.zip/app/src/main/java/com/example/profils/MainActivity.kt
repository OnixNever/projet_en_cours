package com.example.profils

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {

    private val FOND = Color.parseColor("#121212")
    private val CARTE = Color.parseColor("#1E1E1E")
    private val BARRE = Color.parseColor("#181818")
    private val TEXTE = Color.parseColor("#EEEEEE")
    private val ATTENUE = Color.parseColor("#9A9A9A")

    private lateinit var depot: DepotProfils
    private val profils = mutableListOf<Profil>()
    private val webviews = mutableMapOf<String, WebView>()
    private var courant: Profil? = null
    private var isolationOk = false

    private lateinit var ecranListe: LinearLayout
    private lateinit var conteneurListe: LinearLayout
    private lateinit var ecranNavigateur: LinearLayout
    private lateinit var conteneurWeb: FrameLayout
    private lateinit var puce: TextView
    private lateinit var barreUrl: EditText
    private lateinit var progression: ProgressBar
    private lateinit var avertissement: TextView

    private class Attente(val profil: Profil, val demande: PermissionRequest, val ressources: List<String>)
    private var attente: Attente? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fond(couleur: Int, rayon: Int) = GradientDrawable().apply {
        setColor(couleur); cornerRadius = dp(rayon).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = FOND
        window.navigationBarColor = FOND
        depot = DepotProfils(this)
        profils.addAll(depot.charger())
        isolationOk = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
        construireUi()
        rafraichirListe()
    }

    // ───────────────────────── Interface ─────────────────────────

    private fun bouton(label: String, couleur: Int = CARTE, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(TEXTE); isAllCaps = false
        background = fond(couleur, 12); setOnClickListener { action() }
    }

    private fun construireUi() {
        val racine = FrameLayout(this).apply { setBackgroundColor(FOND) }

        // ----- Écran 1 : liste des profils -----
        ecranListe = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(16)) }
        ecranListe.addView(TextView(this).apply { text = "Profils"; textSize = 28f; setTextColor(TEXTE) })
        avertissement = TextView(this).apply {
            text = "⚠ Isolation indisponible sur cet appareil (WebView trop ancienne) : les profils partageraient leurs cookies."
            setTextColor(Color.parseColor("#FFB84D")); textSize = 12f
            setPadding(0, dp(8), 0, dp(8))
            visibility = if (isolationOk) View.GONE else View.VISIBLE
        }
        ecranListe.addView(avertissement)
        conteneurListe = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ecranListe.addView(ScrollView(this).apply { addView(conteneurListe) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        ecranListe.addView(bouton("＋  Nouveau profil", Color.parseColor("#2D4F99")) { dialogueProfil(null) },
            LinearLayout.LayoutParams(-1, dp(52)))
        racine.addView(ecranListe, FrameLayout.LayoutParams(-1, -1))

        // ----- Écran 2 : navigateur -----
        ecranNavigateur = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val haut = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(BARRE); setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        haut.addView(bouton("←") { afficherListe() }, LinearLayout.LayoutParams(dp(48), dp(40)))
        puce = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { dialogueChangerProfil() }
        }
        haut.addView(puce, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)).apply { setMargins(dp(6), 0, dp(6), 0) })
        barreUrl = EditText(this).apply {
            setTextColor(TEXTE); setHintTextColor(ATTENUE); hint = "Adresse ou recherche"
            textSize = 13f; setSingleLine(); inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO; background = fond(CARTE, 10)
            setPadding(dp(12), 0, dp(12), 0)
            setOnEditorActionListener { _, _, _ ->
                naviguer(text.toString().trim())
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(windowToken, 0)
                true
            }
        }
        haut.addView(barreUrl, LinearLayout.LayoutParams(0, dp(40), 1f))
        haut.addView(bouton("⚙") { courant?.let { dialogueProfil(it) } }, LinearLayout.LayoutParams(dp(48), dp(40)).apply { leftMargin = dp(6) })
        ecranNavigateur.addView(haut)
        progression = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        ecranNavigateur.addView(progression, LinearLayout.LayoutParams(-1, dp(3)))
        conteneurWeb = FrameLayout(this)
        ecranNavigateur.addView(conteneurWeb, LinearLayout.LayoutParams(-1, 0, 1f))
        racine.addView(ecranNavigateur, FrameLayout.LayoutParams(-1, -1))

        setContentView(racine)
    }

    private fun rafraichirListe() {
        conteneurListe.removeAllViews()
        if (profils.isEmpty()) {
            conteneurListe.addView(TextView(this).apply {
                text = "Aucun profil. Créez-en un pour commencer."
                setTextColor(ATTENUE); setPadding(0, dp(24), 0, 0)
            })
        }
        profils.forEach { p ->
            val ligne = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = fond(CARTE, 14); setPadding(dp(14), dp(14), dp(14), dp(14))
                setOnClickListener { ouvrirProfil(p) }
                setOnLongClickListener { dialogueProfil(p); true }
            }
            ligne.addView(TextView(this).apply {
                text = p.nom.take(1).uppercase(); gravity = Gravity.CENTER; textSize = 18f
                setTextColor(texteSur(p.couleur)); background = fond(p.couleur, 24)
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
            val textes = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
            textes.addView(TextView(this).apply { text = p.nom; textSize = 17f; setTextColor(TEXTE) })
            textes.addView(TextView(this).apply {
                text = "Micro ${if (p.micro) "✓" else "✗"}  ·  Caméra ${if (p.camera) "✓" else "✗"}"
                textSize = 12f; setTextColor(ATTENUE)
            })
            ligne.addView(textes, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ligne.addView(TextView(this).apply {
                text = "⋮"; textSize = 22f; setTextColor(ATTENUE); setPadding(dp(12), 0, dp(4), 0)
                setOnClickListener { dialogueProfil(p) }
            })
            conteneurListe.addView(ligne, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }
    }

    // ───────────────────────── Dialogues ─────────────────────────

    private fun texteSur(couleur: Int): Int {
        val lum = 0.299 * Color.red(couleur) + 0.587 * Color.green(couleur) + 0.114 * Color.blue(couleur)
        return if (lum > 150) Color.BLACK else Color.WHITE
    }

    private fun interrupteur(label: String, etat: Boolean) = Switch(this).apply {
        text = label; isChecked = etat; setTextColor(TEXTE); setPadding(0, dp(10), 0, dp(10))
    }

    /** Création (existant = null) ou modification d'un profil. */
    private fun dialogueProfil(existant: Profil?) {
        val boite = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(10), dp(22), 0) }
        val champNom = EditText(this).apply {
            hint = "Nom du profil"; setSingleLine(); setText(existant?.nom ?: "")
            setTextColor(TEXTE); setHintTextColor(ATTENUE)
        }
        boite.addView(champNom)
        var couleurChoisie = existant?.couleur ?: Profil.COULEURS[profils.size % Profil.COULEURS.size]
        val apercu = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 18f
            text = (champNom.text.toString().ifEmpty { "?" }).take(1).uppercase()
        }
        val selecteur = SelecteurCouleur(this)
        fun majApercu() {
            apercu.background = fond(couleurChoisie, 22)
            apercu.setTextColor(texteSur(couleurChoisie))
        }
        selecteur.couleur = couleurChoisie
        selecteur.auChangement = { c -> couleurChoisie = c; majApercu() }
        majApercu()
        val rangee = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(10)) }
        rangee.addView(apercu, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) })
        Profil.COULEURS.forEach { c ->
            val v = View(this).apply {
                background = fond(c, 16)
                setOnClickListener { couleurChoisie = c; selecteur.couleur = c; majApercu() }
            }
            rangee.addView(v, LinearLayout.LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(8) })
        }
        boite.addView(rangee)
        boite.addView(selecteur, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        val swMicro = interrupteur("Autoriser le micro", existant?.micro ?: false)
        val swCam = interrupteur("Autoriser la caméra", existant?.camera ?: false)
        boite.addView(swMicro); boite.addView(swCam)

        val b = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(if (existant == null) "Nouveau profil" else "Profil « ${existant.nom} »")
            .setView(ScrollView(this).apply { addView(boite) })
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val nom = champNom.text.toString().trim().ifEmpty { "Profil ${profils.size + 1}" }
                if (existant == null) {
                    profils.add(Profil.nouveau(nom, couleurChoisie, swMicro.isChecked, swCam.isChecked))
                } else {
                    existant.nom = nom; existant.couleur = couleurChoisie
                    existant.micro = swMicro.isChecked; existant.camera = swCam.isChecked
                    if (courant?.id == existant.id) majPuce()
                }
                depot.sauver(profils); rafraichirListe()
            }
        if (existant != null) b.setNeutralButton("Supprimer") { _, _ -> confirmerSuppression(existant) }
        b.show()
    }

    private fun confirmerSuppression(p: Profil) {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Supprimer « ${p.nom} » ?")
            .setMessage("Les cookies, connexions et données de ce profil seront effacés définitivement.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Supprimer") { _, _ -> supprimerProfil(p) }
            .show()
    }

    private fun dialogueChangerProfil() {
        if (profils.isEmpty()) return
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Changer de profil")
            .setItems(profils.map { it.nom }.toTypedArray()) { _, i -> ouvrirProfil(profils[i]) }
            .show()
    }

    // ───────────────────────── Navigation entre profils ─────────────────────────

    private fun afficherListe() {
        fermerToutesPopups()
        courant = null
        ecranNavigateur.visibility = View.GONE
        ecranListe.visibility = View.VISIBLE
        rafraichirListe()
    }

    private fun majPuce() {
        val p = courant ?: return
        puce.text = p.nom
        puce.background = fond(p.couleur, 17)
        puce.setTextColor(texteSur(p.couleur))
    }

    private fun ouvrirProfil(p: Profil) {
        courant = p
        val nouvelle = !webviews.containsKey(p.id)
        val wv = webviews.getOrPut(p.id) { creerWebView(p) }
        fermerToutesPopups()
        conteneurWeb.removeAllViews()
        (wv.parent as? ViewGroup)?.removeView(wv)
        conteneurWeb.addView(wv, FrameLayout.LayoutParams(-1, -1))
        ecranListe.visibility = View.GONE
        ecranNavigateur.visibility = View.VISIBLE
        majPuce()
        if (nouvelle) wv.loadUrl(if (p.url.isNotEmpty()) p.url else "https://www.google.com/")
        barreUrl.setText(wv.url ?: p.url)
        progression.visibility = View.GONE
    }

    private fun naviguer(saisie: String) {
        if (saisie.isEmpty()) return
        val url = when {
            saisie.startsWith("http://") || saisie.startsWith("https://") -> saisie
            !saisie.contains(" ") && saisie.contains(".") -> "https://$saisie"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(saisie, "UTF-8")
        }
        val p = courant ?: return
        webviews[p.id]?.loadUrl(url)
    }

    // ───────────────────────── WebView par profil ─────────────────────────

    /** Applique profil, cookies et réglages. setProfile doit précéder tout autre usage de la WebView. */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configurer(wv: WebView, p: Profil) {
        if (isolationOk) {
            val profil = ProfileStore.getInstance().getOrCreateProfile(p.nomInterne)
            WebViewCompat.setProfile(wv, p.nomInterne)
            profil.cookieManager.setAcceptThirdPartyCookies(wv, true)
        } else {
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        }
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            // Indispensable pour la connexion Google (fenêtre pop-up qui renvoie le résultat à la page)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            // Google refuse la connexion dans une WebView « brute » : on retire les marqueurs « wv »
            userAgentString = userAgentString.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
        }
        wv.setBackgroundColor(FOND)
    }

    private fun creerWebView(p: Profil): WebView {
        val wv = WebView(this)
        configurer(wv, p)
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (courant?.id == p.id) barreUrl.setText(url)
                if (url.startsWith("http")) { p.url = url; depot.sauver(profils) }
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, progress: Int) {
                if (courant?.id != p.id) return
                progression.progress = progress
                progression.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { traiterDemande(p, request) }
            }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                return ouvrirPopup(p, resultMsg)
            }
        }
        return wv
    }

    /** Pop-up (connexion Google, etc.) : WebView enfant du MÊME profil, posée par-dessus la page. */
    private fun ouvrirPopup(p: Profil, resultMsg: android.os.Message): Boolean {
        val popup = WebView(this)
        configurer(popup, p)
        val zone = FrameLayout(this).apply { setBackgroundColor(FOND); isClickable = true }
        popup.webViewClient = WebViewClient()
        popup.webChromeClient = object : WebChromeClient() {
            override fun onCloseWindow(window: WebView) {
                runOnUiThread { fermerPopup(window) }
            }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, msg: android.os.Message): Boolean {
                return ouvrirPopup(p, msg)
            }
        }
        zone.addView(popup, FrameLayout.LayoutParams(-1, -1))
        zone.tag = popup
        conteneurWeb.addView(zone, FrameLayout.LayoutParams(-1, -1))
        val transport = resultMsg.obj as WebView.WebViewTransport
        transport.webView = popup
        resultMsg.sendToTarget()
        return true
    }

    private fun fermerPopup(popup: WebView) {
        val zone = popup.parent as? ViewGroup ?: return
        (zone.parent as? ViewGroup)?.removeView(zone)
        zone.removeAllViews()
        popup.destroy()
    }

    private fun fermerToutesPopups() {
        while (true) { fermerPopup(popupOuverte() ?: break) }
    }

    /** Ferme la pop-up la plus récente du conteneur, si elle existe. */
    private fun popupOuverte(): WebView? {
        for (i in conteneurWeb.childCount - 1 downTo 0) {
            val t = conteneurWeb.getChildAt(i).tag
            if (t is WebView) return t
        }
        return null
    }

    private fun supprimerProfil(p: Profil) {
        val wv = webviews.remove(p.id)
        if (wv != null) {
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        if (isolationOk) {
            try {
                val store = ProfileStore.getInstance()
                // Efface d'abord les données (au cas où la suppression échoue), puis supprime le profil
                store.getProfile(p.nomInterne)?.let {
                    it.cookieManager.removeAllCookies(null)
                    it.webStorage.deleteAllData()
                }
                store.deleteProfile(p.nomInterne)
            } catch (e: Exception) {
                Toast.makeText(this, "Profil retiré (données à purger au prochain démarrage)", Toast.LENGTH_LONG).show()
            }
        }
        profils.removeAll { it.id == p.id }
        depot.sauver(profils)
        if (courant?.id == p.id) afficherListe() else rafraichirListe()
    }

    // ───────────────────────── Permissions par profil ─────────────────────────

    private fun traiterDemande(p: Profil, demande: PermissionRequest) {
        val voulues = mutableListOf<String>()
        demande.resources.forEach { r ->
            if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE && p.micro) voulues.add(r)
            if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE && p.camera) voulues.add(r)
        }
        if (voulues.isEmpty()) { demande.deny(); return }

        val androidPerms = voulues.map {
            if (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE) Manifest.permission.RECORD_AUDIO
            else Manifest.permission.CAMERA
        }
        val manquantes = androidPerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (manquantes.isEmpty()) {
            demande.grant(voulues.toTypedArray())
        } else {
            attente = Attente(p, demande, voulues)
            requestPermissions(manquantes.toTypedArray(), 42)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        val a = attente ?: return
        attente = null
        val accordees = a.ressources.filter {
            val perm = if (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE) Manifest.permission.RECORD_AUDIO else Manifest.permission.CAMERA
            checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
        }
        if (accordees.isEmpty()) a.demande.deny() else a.demande.grant(accordees.toTypedArray())
    }

    // ───────────────────────── Cycle de vie ─────────────────────────

    override fun onPause() { super.onPause(); webviews.values.forEach { it.onPause() } }
    override fun onResume() { super.onResume(); webviews.values.forEach { it.onResume() } }

    override fun onBackPressed() {
        val p = courant
        if (p == null) { super.onBackPressed(); return }
        popupOuverte()?.let { fermerPopup(it); return }
        val wv = webviews[p.id]
        if (wv != null && wv.canGoBack()) wv.goBack() else afficherListe()
    }
}
