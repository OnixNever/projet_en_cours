package com.example.profils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View

/** Palette libre : carré saturation/luminosité + barre de teinte. */
class SelecteurCouleur(context: Context) : View(context) {
    private val d = resources.displayMetrics.density
    private val hsv = floatArrayOf(210f, 0.7f, 0.9f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val curseur = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val hauteurBarre = 30 * d
    private val espace = 12 * d
    var auChangement: ((Int) -> Unit)? = null

    var couleur: Int
        get() = Color.HSVToColor(hsv)
        set(c) { Color.colorToHSV(c, hsv); invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val largeur = MeasureSpec.getSize(w)
        setMeasuredDimension(largeur, (largeur * 0.62f + espace + hauteurBarre).toInt())
    }

    private fun hCarre() = height - espace - hauteurBarre

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val hc = hCarre()
        // Carré saturation (horizontal) / luminosité (vertical)
        val teinte = Color.HSVToColor(floatArrayOf(hsv[0], 1f, 1f))
        val sh = ComposeShader(
            LinearGradient(0f, 0f, 0f, hc, Color.WHITE, Color.BLACK, Shader.TileMode.CLAMP),
            LinearGradient(0f, 0f, w, 0f, Color.WHITE, teinte, Shader.TileMode.CLAMP),
            PorterDuff.Mode.MULTIPLY
        )
        paint.shader = sh
        c.drawRoundRect(0f, 0f, w, hc, 10 * d, 10 * d, paint)
        // Barre de teinte
        val cols = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        paint.shader = LinearGradient(0f, 0f, w, 0f, cols, null, Shader.TileMode.CLAMP)
        val top = hc + espace
        c.drawRoundRect(0f, top, w, top + hauteurBarre, 10 * d, 10 * d, paint)
        paint.shader = null
        // Curseurs
        val cx = hsv[1] * w; val cy = (1f - hsv[2]) * hc
        curseur.color = Color.WHITE; c.drawCircle(cx, cy, 10 * d, curseur)
        curseur.color = Color.BLACK; c.drawCircle(cx, cy, 12 * d, curseur.apply { strokeWidth = 1.2f * d })
        curseur.strokeWidth = 2.5f * d
        val hx = hsv[0] / 360f * w
        curseur.color = Color.WHITE
        c.drawRoundRect(hx - 4 * d, top - 2 * d, hx + 4 * d, top + hauteurBarre + 2 * d, 4 * d, 4 * d, curseur)
    }

    private var zone = 0 // 1 = carré, 2 = barre de teinte

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                zone = if (e.y <= hCarre() + espace / 2) 1 else 2
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { zone = 0; return true }
        }
        val x = e.x.coerceIn(0f, width.toFloat())
        if (zone == 1) {
            hsv[1] = x / width
            hsv[2] = 1f - (e.y.coerceIn(0f, hCarre()) / hCarre())
        } else if (zone == 2) {
            hsv[0] = (x / width * 360f).coerceAtMost(359.9f)
        }
        invalidate()
        auChangement?.invoke(couleur)
        return true
    }
}
