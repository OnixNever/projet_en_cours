package com.example.profils

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class Moteur(val id: String, val nom: String, val recherche: String, val accueil: String)

data class Profil(
    val id: String,
    var nom: String,
    var couleur: Int,
    var micro: Boolean,
    var camera: Boolean,
    var moteur: String = "ddg",
    val onglets: MutableList<String> = mutableListOf(),
    var actif: Int = 0
) {
    /** Nom du profil WebView (caractères autorisés : lettres, chiffres, _ et -). */
    val nomInterne: String get() = "p_$id"

    companion object {
        val COULEURS = intArrayOf(
            0xFF4F8CFF.toInt(), 0xFF3DDC97.toInt(), 0xFFFFB84D.toInt(),
            0xFFFF6B6B.toInt(), 0xFFB28DFF.toInt(), 0xFF4DD0E1.toInt()
        )
        val MOTEURS = listOf(
            Moteur("ddg", "DuckDuckGo", "https://duckduckgo.com/?q=", "https://duckduckgo.com/"),
            Moteur("google", "Google", "https://www.google.com/search?q=", "https://www.google.com/"),
            Moteur("bing", "Bing", "https://www.bing.com/search?q=", "https://www.bing.com/"),
            Moteur("brave", "Brave Search", "https://search.brave.com/search?q=", "https://search.brave.com/"),
            Moteur("qwant", "Qwant", "https://www.qwant.com/?q=", "https://www.qwant.com/")
        )
        fun moteur(id: String): Moteur = MOTEURS.firstOrNull { it.id == id } ?: MOTEURS[0]

        fun nouveau(nom: String, couleur: Int, micro: Boolean, camera: Boolean) =
            Profil(UUID.randomUUID().toString().replace("-", "").take(12), nom, couleur, micro, camera)
    }
}

/** Sauvegarde de la liste des profils (SharedPreferences, JSON). */
class DepotProfils(context: Context) {
    private val prefs = context.getSharedPreferences("profils", Context.MODE_PRIVATE)

    fun charger(): MutableList<Profil> {
        val liste = mutableListOf<Profil>()
        try {
            val arr = JSONArray(prefs.getString("liste", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val onglets = mutableListOf<String>()
                val ao = o.optJSONArray("onglets")
                if (ao != null) {
                    for (j in 0 until ao.length()) onglets.add(ao.getString(j))
                } else if (o.optString("url", "").isNotEmpty()) {
                    onglets.add(o.getString("url")) // ancienne version : une seule page
                }
                liste.add(
                    Profil(
                        o.getString("id"), o.getString("nom"), o.getInt("couleur"),
                        o.optBoolean("micro", false), o.optBoolean("camera", false),
                        o.optString("moteur", "ddg"), onglets, o.optInt("actif", 0)
                    )
                )
            }
        } catch (e: Exception) { /* liste corrompue : on repart de zéro */ }
        return liste
    }

    fun sauver(liste: List<Profil>) {
        val arr = JSONArray()
        liste.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("nom", it.nom); put("couleur", it.couleur)
                put("micro", it.micro); put("camera", it.camera); put("moteur", it.moteur)
                put("onglets", JSONArray(it.onglets)); put("actif", it.actif)
            })
        }
        prefs.edit().putString("liste", arr.toString()).apply()
    }
}
