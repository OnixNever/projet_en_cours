package com.example.profils

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.security.MessageDigest
import java.security.SecureRandom

class MainActivity : Activity() {

    // ───────── Thème (sombre par défaut, clair en option) ─────────
    private var sombre = true
    private val FOND get() = Color.parseColor(if (sombre) "#121212" else "#F4F5F7")
    private val CARTE get() = Color.parseColor(if (sombre) "#1E1E1E" else "#FFFFFF")
    private val BARRE get() = Color.parseColor(if (sombre) "#181818" else "#E9EBEE")
    private val TEXTE get() = Color.parseColor(if (sombre) "#EEEEEE" else "#1A1A1A")
    private val ATTENUE get() = Color.parseColor(if (sombre) "#9A9A9A" else "#6B6B6B")
    private val themeDialogue get() =
        if (sombre) AlertDialog.THEME_DEVICE_DEFAULT_DARK else AlertDialog.THEME_DEVICE_DEFAULT_LIGHT

    private lateinit var depot: DepotProfils
    private lateinit var reglages: SharedPreferences
    private val profils = mutableListOf<Profil>()

    /** Un onglet = une WebView ; enAttente = adresse à charger au premier affichage. */
    private class Onglet(val wv: WebView, var enAttente: String?, var titre: String = "")
    private val onglets = mutableMapOf<String, MutableList<Onglet>>()

    private var courant: Profil? = null
    private var isolationOk = false

    private lateinit var ecranListe: LinearLayout
    private lateinit var conteneurListe: LinearLayout
    private lateinit var ecranNavigateur: LinearLayout
    private lateinit var conteneurWeb: FrameLayout
    private lateinit var barreOnglets: LinearLayout
    private lateinit var puce: TextView
    private lateinit var barreUrl: EditText
    private lateinit var progression: ProgressBar
    private lateinit var avertissement: TextView

    private class Attente(val demande: PermissionRequest, val ressources: List<String>)
    private var attente: Attente? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fond(couleur: Int, rayon: Int) = GradientDrawable().apply {
        setColor(couleur); cornerRadius = dp(rayon).toFloat()
    }

    private fun texteSur(couleur: Int): Int {
        val lum = 0.299 * Color.red(couleur) + 0.587 * Color.green(couleur) + 0.114 * Color.blue(couleur)
        return if (lum > 150) Color.BLACK else Color.WHITE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        reglages = getSharedPreferences("reglages", MODE_PRIVATE)
        sombre = reglages.getBoolean("sombre", true)
        barresSysteme()
        depot = DepotProfils(this)
        profils.addAll(depot.charger())
        isolationOk = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
        construireUi()
        rafraichirListe()
        // Après un changement de thème, on rouvre le profil qui était affiché
        val id = reglages.getString("reouvrir", "") ?: ""
        if (id.isNotEmpty()) {
            reglages.edit().remove("reouvrir").apply()
            profils.firstOrNull { it.id == id }?.let { ouvrirProfil(it) }
        }
    }

    @Suppress("DEPRECATION")
    private fun barresSysteme() {
        window.statusBarColor = FOND
        window.navigationBarColor = FOND
        window.decorView.systemUiVisibility =
            if (sombre) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }

    private fun changerTheme() {
        reglages.edit().putBoolean("sombre", !sombre).putString("reouvrir", courant?.id ?: "").apply()
        recreate()
    }

    // ───────────────────────── Interface ─────────────────────────

    private fun bouton(label: String, couleur: Int = CARTE, texte: Int = TEXTE, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(texte); isAllCaps = false
        background = fond(couleur, 12); setOnClickListener { action() }
    }

    private fun construireUi() {
        val racine = FrameLayout(this).apply { setBackgroundColor(FOND) }

        // ----- Écran 1 : liste des profils -----
        ecranListe = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(16)) }
        val entete = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        entete.addView(TextView(this).apply { text = "Profils"; textSize = 28f; setTextColor(TEXTE) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        entete.addView(bouton("⚙") { dialogueReglages() }, LinearLayout.LayoutParams(dp(48), dp(40)))
        ecranListe.addView(entete)
        avertissement = TextView(this).apply {
            text = "⚠ Isolation indisponible sur cet appareil (WebView trop ancienne) : les profils partageraient leurs cookies."
            setTextColor(Color.parseColor("#FFB84D")); textSize = 12f
            setPadding(0, dp(8), 0, dp(8))
            visibility = if (isolationOk) View.GONE else View.VISIBLE
        }
        ecranListe.addView(avertissement)
        conteneurListe = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, 0) }
        ecranListe.addView(ScrollView(this).apply { addView(conteneurListe) }, LinearLayout.LayoutParams(-1, 0, 1f))
        ecranListe.addView(bouton("＋  Nouveau profil", Color.parseColor("#2D4F99"), Color.WHITE) { protege { dialogueProfil(null) } },
            LinearLayout.LayoutParams(-1, dp(52)))
        racine.addView(ecranListe, FrameLayout.LayoutParams(-1, -1))

        // ----- Écran 2 : navigateur -----
        ecranNavigateur = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val haut = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(BARRE); setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        haut.addView(bouton("←") { afficherListe() }, LinearLayout.LayoutParams(dp(48), dp(40)))
        puce = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { dialogueChangerProfil() }
        }
        haut.addView(puce, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)).apply { setMargins(dp(6), 0, dp(6), 0) })
        barreUrl = EditText(this).apply {
            setTextColor(TEXTE); setHintTextColor(ATTENUE); hint = "Adresse ou recherche"
            textSize = 13f; setSingleLine(); inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO; background = fond(CARTE, 10)
            setPadding(dp(12), 0, dp(12), 0)
            setOnEditorActionListener { _, _, _ ->
                naviguer(text.toString().trim())
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(windowToken, 0)
                true
            }
        }
        haut.addView(barreUrl, LinearLayout.LayoutParams(0, dp(40), 1f))
        haut.addView(bouton("⚙") { menuNavigateur() }, LinearLayout.LayoutParams(dp(48), dp(40)).apply { leftMargin = dp(6) })
        ecranNavigateur.addView(haut)

        barreOnglets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        ecranNavigateur.addView(HorizontalScrollView(this).apply {
            setBackgroundColor(BARRE); isHorizontalScrollBarEnabled = false; addView(barreOnglets)
        }, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        progression = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        ecranNavigateur.addView(progression, LinearLayout.LayoutParams(-1, dp(3)))
        conteneurWeb = FrameLayout(this)
        ecranNavigateur.addView(conteneurWeb, LinearLayout.LayoutParams(-1, 0, 1f))
        racine.addView(ecranNavigateur, FrameLayout.LayoutParams(-1, -1))

        setContentView(racine)
    }

    private fun rafraichirListe() {
        conteneurListe.removeAllViews()
        if (profils.isEmpty()) {
            conteneurListe.addView(TextView(this).apply {
                text = "Aucun profil. Créez-en un pour commencer."
                setTextColor(ATTENUE); setPadding(0, dp(12), 0, 0)
            })
        }
        profils.forEach { p ->
            val ligne = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = fond(CARTE, 14); setPadding(dp(14), dp(14), dp(14), dp(14))
                setOnClickListener { ouvrirProfil(p) }
                setOnLongClickListener { protege { dialogueProfil(p) }; true }
            }
            ligne.addView(TextView(this).apply {
                text = p.nom.take(1).uppercase(); gravity = Gravity.CENTER; textSize = 18f
                setTextColor(texteSur(p.couleur)); background = fond(p.couleur, 24)
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
            val textes = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
            textes.addView(TextView(this).apply { text = p.nom; textSize = 17f; setTextColor(TEXTE) })
            textes.addView(TextView(this).apply {
                text = "Micro ${if (p.micro) "✓" else "✗"}  ·  Caméra ${if (p.camera) "✓" else "✗"}  ·  ${Profil.moteur(p.moteur).nom}"
                textSize = 12f; setTextColor(ATTENUE)
            })
            ligne.addView(textes, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ligne.addView(TextView(this).apply {
                text = "⋮"; textSize = 22f; setTextColor(ATTENUE); setPadding(dp(12), 0, dp(4), 0)
                setOnClickListener { protege { dialogueProfil(p) } }
            })
            conteneurListe.addView(ligne, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }
    }

    // ───────────────────────── Code maître ─────────────────────────

    private fun hacher(code: String, sel: String): String =
        MessageDigest.getInstance("SHA-256").digest((sel + code).toByteArray()).joinToString("") { "%02x".format(it) }

    private fun codeDefini() = reglages.getString("codeHash", null) != null

    private fun champCode(titre: String, message: String?, ok: (String) -> Unit) {
        val champ = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "Code"; setTextColor(TEXTE); setHintTextColor(ATTENUE); setSingleLine()
        }
        val boite = LinearLayout(this).apply { setPadding(dp(22), dp(10), dp(22), 0); addView(champ, LinearLayout.LayoutParams(-1, -2)) }
        val b = AlertDialog.Builder(this, themeDialogue).setTitle(titre).setView(boite)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("OK") { _, _ -> ok(champ.text.toString()) }
        if (message != null) b.setMessage(message)
        b.show()
    }

    /** Exécute l'action seulement si le code maître est correct (ou le crée à la première utilisation). */
    private fun protege(action: () -> Unit) {
        val h = reglages.getString("codeHash", null)
        if (h == null) { creerCode(action); return }
        champCode("Code maître", null) { c ->
            if (hacher(c, reglages.getString("codeSel", "") ?: "") == h) action()
            else Toast.makeText(this, "Code incorrect", Toast.LENGTH_SHORT).show()
        }
    }

    private fun creerCode(apres: () -> Unit) {
        champCode("Créer le code maître", "Il protège la création des profils et le réglage de leurs autorisations. 4 caractères minimum.") { c1 ->
            if (c1.length < 4) {
                Toast.makeText(this, "Code trop court", Toast.LENGTH_SHORT).show()
            } else {
                champCode("Confirmer le code", null) { c2 ->
                    if (c1 != c2) {
                        Toast.makeText(this, "Les deux codes sont différents", Toast.LENGTH_SHORT).show()
                    } else {
                        val octets = ByteArray(16).also { SecureRandom().nextBytes(it) }
                        val sel = octets.joinToString("") { "%02x".format(it) }
                        reglages.edit().putString("codeSel", sel).putString("codeHash", hacher(c1, sel)).apply()
                        Toast.makeText(this, "Code maître enregistré", Toast.LENGTH_SHORT).show()
                        apres()
                    }
                }
            }
        }
    }

    // ───────────────────────── Dialogues ─────────────────────────

    private fun interrupteur(label: String, etat: Boolean) = Switch(this).apply {
        text = label; isChecked = etat; setTextColor(TEXTE); setPadding(0, dp(10), 0, dp(10))
    }

    private fun dialogueReglages() {
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Paramètres")
            .setItems(arrayOf(
                if (sombre) "Passer en mode clair" else "Passer en mode sombre",
                if (codeDefini()) "Modifier le code maître" else "Créer le code maître"
            )) { _, i ->
                if (i == 0) changerTheme()
                else if (codeDefini()) protege { creerCode { } } else creerCode { }
            }
            .show()
    }

    /** Création (existant = null) ou modification d'un profil (appelé via protege()). */
    private fun dialogueProfil(existant: Profil?) {
        val boite = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(10), dp(22), 0) }
        val champNom = EditText(this).apply {
            hint = "Nom du profil"; setSingleLine(); setText(existant?.nom ?: "")
            setTextColor(TEXTE); setHintTextColor(ATTENUE)
        }
        boite.addView(champNom)
        var couleurChoisie = existant?.couleur ?: Profil.COULEURS[profils.size % Profil.COULEURS.size]
        val apercu = TextView(this).apply { gravity = Gravity.CENTER; textSize = 18f; text = (existant?.nom ?: "?").take(1).uppercase() }
        val selecteur = SelecteurCouleur(this)
        fun majApercu() {
            apercu.background = fond(couleurChoisie, 22)
            apercu.setTextColor(texteSur(couleurChoisie))
        }
        selecteur.couleur = couleurChoisie
        selecteur.auChangement = { c -> couleurChoisie = c; majApercu() }
        majApercu()
        val rangee = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(10)) }
        rangee.addView(apercu, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) })
        Profil.COULEURS.forEach { c ->
            val v = View(this).apply {
                background = fond(c, 16)
                setOnClickListener { couleurChoisie = c; selecteur.couleur = c; majApercu() }
            }
            rangee.addView(v, LinearLayout.LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(8) })
        }
        boite.addView(rangee)
        boite.addView(selecteur, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        val swMicro = interrupteur("Autoriser le micro", existant?.micro ?: false)
        val swCam = interrupteur("Autoriser la caméra", existant?.camera ?: false)
        boite.addView(swMicro); boite.addView(swCam)

        val b = AlertDialog.Builder(this, themeDialogue)
            .setTitle(if (existant == null) "Nouveau profil" else "Profil « ${existant.nom} »")
            .setView(ScrollView(this).apply { addView(boite) })
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val nom = champNom.text.toString().trim().ifEmpty { "Profil ${profils.size + 1}" }
                if (existant == null) {
                    profils.add(Profil.nouveau(nom, couleurChoisie, swMicro.isChecked, swCam.isChecked))
                } else {
                    existant.nom = nom; existant.couleur = couleurChoisie
                    existant.micro = swMicro.isChecked; existant.camera = swCam.isChecked
                    if (courant?.id == existant.id) majPuce()
                }
                depot.sauver(profils); rafraichirListe()
            }
        if (existant != null) b.setNeutralButton("Supprimer") { _, _ -> confirmerSuppression(existant) }
        b.show()
    }

    private fun confirmerSuppression(p: Profil) {
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Supprimer « ${p.nom} » ?")
            .setMessage("Les cookies, connexions et données de ce profil seront effacés définitivement.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Supprimer") { _, _ -> supprimerProfil(p) }
            .show()
    }

    private fun dialogueChangerProfil() {
        if (profils.isEmpty()) return
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Changer de profil")
            .setItems(profils.map { it.nom }.toTypedArray()) { _, i -> ouvrirProfil(profils[i]) }
            .show()
    }

    /** Menu ⚙ du navigateur : onglets et paramètres (les autorisations restent à l'extérieur). */
    private fun menuNavigateur() {
        val p = courant ?: return
        val libelles = arrayOf(
            "Nouvel onglet",
            "Actualiser",
            "Moteur de recherche : ${Profil.moteur(p.moteur).nom}",
            if (sombre) "Passer en mode clair" else "Passer en mode sombre",
            "Fermer cet onglet"
        )
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Profil « ${p.nom} »")
            .setItems(libelles) { _, i ->
                when (i) {
                    0 -> nouvelOnglet()
                    1 -> wvActif()?.reload()
                    2 -> dialogueMoteur(p)
                    3 -> changerTheme()
                    4 -> fermerOnglet(p.actif)
                }
            }
            .show()
    }

    private fun dialogueMoteur(p: Profil) {
        val noms = Profil.MOTEURS.map { it.nom }.toTypedArray()
        val actuel = Profil.MOTEURS.indexOfFirst { it.id == p.moteur }.coerceAtLeast(0)
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Moteur de recherche")
            .setSingleChoiceItems(noms, actuel) { d, i ->
                p.moteur = Profil.MOTEURS[i].id
                depot.sauver(profils); rafraichirListe(); d.dismiss()
            }
            .show()
    }

    // ───────────────────────── Profils et onglets ─────────────────────────

    private fun afficherListe() {
        fermerToutesPopups()
        courant = null
        ecranNavigateur.visibility = View.GONE
        ecranListe.visibility = View.VISIBLE
        rafraichirListe()
    }

    private fun majPuce() {
        val p = courant ?: return
        puce.text = p.nom
        puce.background = fond(p.couleur, 17)
        puce.setTextColor(texteSur(p.couleur))
    }

    private fun accueil(p: Profil) = Profil.moteur(p.moteur).accueil

    private fun wvActif(): WebView? {
        val p = courant ?: return null
        return onglets[p.id]?.getOrNull(p.actif)?.wv
    }

    private fun estActif(p: Profil, o: Onglet) =
        courant?.id == p.id && onglets[p.id]?.getOrNull(p.actif) === o

    private fun ouvrirProfil(p: Profil) {
        fermerToutesPopups()
        courant = p
        if (p.onglets.isEmpty()) p.onglets.add(accueil(p))
        val liste = onglets.getOrPut(p.id) {
            p.onglets.map { creerOnglet(p, it) }.toMutableList()
        }
        ecranListe.visibility = View.GONE
        ecranNavigateur.visibility = View.VISIBLE
        majPuce()
        afficherOnglet(p.actif.coerceIn(0, liste.size - 1))
    }

    private fun afficherOnglet(i: Int) {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        fermerToutesPopups()
        p.actif = i
        depot.sauver(profils)
        val o = liste[i]
        conteneurWeb.removeAllViews()
        (o.wv.parent as? ViewGroup)?.removeView(o.wv)
        conteneurWeb.addView(o.wv, FrameLayout.LayoutParams(-1, -1))
        o.enAttente?.let { o.enAttente = null; o.wv.loadUrl(it) }
        barreUrl.setText(o.wv.url ?: p.onglets.getOrNull(i) ?: "")
        progression.visibility = View.GONE
        majBarreOnglets()
    }

    private fun nouvelOnglet(url: String? = null) {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        val u = url ?: accueil(p)
        p.onglets.add(u)
        liste.add(creerOnglet(p, u))
        afficherOnglet(liste.size - 1)
    }

    private fun fermerOnglet(i: Int) {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        if (i !in liste.indices) return
        val o = liste.removeAt(i)
        p.onglets.removeAt(i)
        (o.wv.parent as? ViewGroup)?.removeView(o.wv)
        o.wv.destroy()
        if (liste.isEmpty()) {
            val u = accueil(p)
            p.onglets.add(u)
            liste.add(creerOnglet(p, u))
            afficherOnglet(0)
        } else {
            var a = p.actif
            if (i < a) a--
            afficherOnglet(a.coerceIn(0, liste.size - 1))
        }
    }

    private fun majBarreOnglets() {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        barreOnglets.removeAllViews()
        liste.forEachIndexed { i, o ->
            val actifOnglet = i == p.actif
            val couleurTexte = if (actifOnglet) texteSur(p.couleur) else TEXTE
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = fond(if (actifOnglet) p.couleur else CARTE, 10)
                setPadding(dp(12), 0, dp(4), 0)
                setOnClickListener { afficherOnglet(i) }
            }
            val url = o.wv.url ?: p.onglets.getOrNull(i) ?: ""
            val titre = o.titre.ifEmpty { Uri.parse(url).host ?: "Nouvel onglet" }
            chip.addView(TextView(this).apply {
                text = if (titre.length > 16) titre.take(15) + "…" else titre
                textSize = 12f; setTextColor(couleurTexte); setSingleLine()
            })
            chip.addView(TextView(this).apply {
                text = "✕"; textSize = 13f; setTextColor(couleurTexte); gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0)
                setOnClickListener { fermerOnglet(i) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
            barreOnglets.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)).apply { rightMargin = dp(6) })
        }
        barreOnglets.addView(TextView(this).apply {
            text = "＋"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(TEXTE)
            background = fond(CARTE, 10); setOnClickListener { nouvelOnglet() }
        }, LinearLayout.LayoutParams(dp(40), dp(34)))
    }

    private fun naviguer(saisie: String) {
        if (saisie.isEmpty()) return
        val p = courant ?: return
        val url = when {
            saisie.startsWith("http://") || saisie.startsWith("https://") -> saisie
            !saisie.contains(" ") && saisie.contains(".") -> "https://$saisie"
            else -> Profil.moteur(p.moteur).recherche + java.net.URLEncoder.encode(saisie, "UTF-8")
        }
        wvActif()?.loadUrl(url)
    }

    // ───────────────────────── WebView par onglet ─────────────────────────

    /** Applique profil, cookies et réglages. setProfile doit précéder tout autre usage de la WebView. */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configurer(wv: WebView, p: Profil) {
        if (isolationOk) {
            val profil = ProfileStore.getInstance().getOrCreateProfile(p.nomInterne)
            WebViewCompat.setProfile(wv, p.nomInterne)
            profil.cookieManager.setAcceptThirdPartyCookies(wv, true)
        } else {
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        }
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            // Indispensable pour la connexion Google (fenêtre pop-up qui renvoie le résultat à la page)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            // Google refuse la connexion dans une WebView « brute » : on retire les marqueurs « wv »
            userAgentString = userAgentString.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
        }
        wv.setBackgroundColor(FOND)
    }

    private fun creerOnglet(p: Profil, url: String): Onglet {
        val wv = WebView(this)
        configurer(wv, p)
        val o = Onglet(wv, url)
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, u: String) {
                if (u.startsWith("http")) {
                    val i = onglets[p.id]?.indexOf(o) ?: -1
                    if (i >= 0 && i < p.onglets.size) { p.onglets[i] = u; depot.sauver(profils) }
                }
                if (estActif(p, o)) barreUrl.setText(u)
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, progress: Int) {
                if (!estActif(p, o)) return
                progression.progress = progress
                progression.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
            }
            override fun onReceivedTitle(view: WebView, title: String?) {
                o.titre = title ?: ""
                if (courant?.id == p.id) majBarreOnglets()
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { traiterDemande(p, request) }
            }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                return ouvrirPopup(p, resultMsg)
            }
        }
        return o
    }

    /** Pop-up (connexion Google, etc.) : WebView enfant du MÊME profil, posée par-dessus la page. */
    private fun ouvrirPopup(p: Profil, resultMsg: android.os.Message): Boolean {
        val popup = WebView(this)
        configurer(popup, p)
        val zone = FrameLayout(this).apply { setBackgroundColor(FOND); isClickable = true }
        popup.webViewClient = WebViewClient()
        popup.webChromeClient = object : WebChromeClient() {
            override fun onCloseWindow(window: WebView) {
                runOnUiThread { fermerPopup(window) }
            }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, msg: android.os.Message): Boolean {
                return ouvrirPopup(p, msg)
            }
        }
        zone.addView(popup, FrameLayout.LayoutParams(-1, -1))
        zone.tag = popup
        conteneurWeb.addView(zone, FrameLayout.LayoutParams(-1, -1))
        val transport = resultMsg.obj as WebView.WebViewTransport
        transport.webView = popup
        resultMsg.sendToTarget()
        return true
    }

    private fun fermerPopup(popup: WebView) {
        val zone = popup.parent as? ViewGroup ?: return
        (zone.parent as? ViewGroup)?.removeView(zone)
        zone.removeAllViews()
        popup.destroy()
    }

    private fun fermerToutesPopups() {
        while (true) { fermerPopup(popupOuverte() ?: break) }
    }

    /** Pop-up la plus récente du conteneur, si elle existe. */
    private fun popupOuverte(): WebView? {
        for (i in conteneurWeb.childCount - 1 downTo 0) {
            val t = conteneurWeb.getChildAt(i).tag
            if (t is WebView) return t
        }
        return null
    }

    private fun detruire(o: Onglet) {
        (o.wv.parent as? ViewGroup)?.removeView(o.wv)
        o.wv.destroy()
    }

    private fun supprimerProfil(p: Profil) {
        if (courant?.id == p.id) fermerToutesPopups()
        onglets.remove(p.id)?.forEach { detruire(it) }
        if (isolationOk) {
            try {
                val store = ProfileStore.getInstance()
                // Efface d'abord les données (au cas où la suppression échoue), puis supprime le profil
                store.getProfile(p.nomInterne)?.let {
                    it.cookieManager.removeAllCookies(null)
                    it.webStorage.deleteAllData()
                }
                store.deleteProfile(p.nomInterne)
            } catch (e: Exception) {
                Toast.makeText(this, "Profil retiré (données à purger au prochain démarrage)", Toast.LENGTH_LONG).show()
            }
        }
        profils.removeAll { it.id == p.id }
        depot.sauver(profils)
        if (courant?.id == p.id) afficherListe() else rafraichirListe()
    }

    // ───────────────────────── Permissions par profil ─────────────────────────

    private fun traiterDemande(p: Profil, demande: PermissionRequest) {
        val voulues = mutableListOf<String>()
        demande.resources.forEach { r ->
            if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE && p.micro) voulues.add(r)
            if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE && p.camera) voulues.add(r)
        }
        if (voulues.isEmpty()) { demande.deny(); return }

        val androidPerms = voulues.map {
            if (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE) Manifest.permission.RECORD_AUDIO
            else Manifest.permission.CAMERA
        }
        val manquantes = androidPerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (manquantes.isEmpty()) {
            demande.grant(voulues.toTypedArray())
        } else {
            attente = Attente(demande, voulues)
            requestPermissions(manquantes.toTypedArray(), 42)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        val a = attente ?: return
        attente = null
        val accordees = a.ressources.filter {
            val perm = if (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE) Manifest.permission.RECORD_AUDIO else Manifest.permission.CAMERA
            checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
        }
        if (accordees.isEmpty()) a.demande.deny() else a.demande.grant(accordees.toTypedArray())
    }

    // ───────────────────────── Cycle de vie ─────────────────────────

    override fun onPause() { super.onPause(); onglets.values.forEach { l -> l.forEach { it.wv.onPause() } } }
    override fun onResume() { super.onResume(); onglets.values.forEach { l -> l.forEach { it.wv.onResume() } } }

    override fun onDestroy() {
        onglets.values.forEach { l -> l.forEach { detruire(it) } }
        onglets.clear()
        super.onDestroy()
    }

    override fun onBackPressed() {
        val p = courant
        if (p == null) { super.onBackPressed(); return }
        popupOuverte()?.let { fermerPopup(it); return }
        val wv = wvActif()
        if (wv != null && wv.canGoBack()) wv.goBack() else afficherListe()
    }
}
